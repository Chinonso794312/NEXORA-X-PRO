OBLIVEX PRIME — Cloudflare Pages upload folder

This is a standalone static website. No build step is required.

Deploy:
1. Sign in at https://dash.cloudflare.com/
2. Open Workers & Pages → Create → Pages → Upload assets (Direct Upload).
3. Upload OBLIVEX_PRIME.zip or the contents of this folder.
4. Name the project oblivex-prime if available, then deploy.
5. Cloudflare will provide a *.pages.dev address.

Notes:
- The purple X logo is currently represented by a stylized X placeholder because the logo image was not available as a separate asset file here. Replace the .logo div in index.html with your image when available.
- Generated numbers are samples only; WhatsApp registration is not verified.
